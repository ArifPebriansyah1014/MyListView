package com.arifpebriansyah.listview;

import android.content.res.TypedArray;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private String[] dataName;
    private String[] dataDescription;
    private TypedArray dataPhoto;
    private MenuMakananAdapter adapter;
    private ArrayList<MenuMakanan> MenuMakanans;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        adapter = new MenuMakananAdapter(this);
        ListView listView = findViewById(R.id.lv_list);
        listView.setAdapter((ListAdapter) adapter);

        prepare();
        addItem();
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(MainActivity.this, MenuMakanans.get(i).getName(), Toast.LENGTH_SHORT).show();
            }
        });
    }
    private void prepare(){
        dataName=getResources().getStringArray(R.array.data_name);
        dataDescription=getResources().getStringArray(R.array.data_description);
        dataPhoto=getResources().obtainTypedArray(R.array.data_photo);
    }
    private void addItem(){
        MenuMakanans = new ArrayList<>();

        for (int i=0; i<dataName.length; i++){
            MenuMakanan MenuMakanan = new MenuMakanan();
            MenuMakanan.setPhoto(dataPhoto.getResourceId(i, -1));
            MenuMakanan.setName(dataName[i]);
            MenuMakanan.setDescription(dataDescription[i]);
            MenuMakanans.add(MenuMakanan);

        }
        adapter.setMenuMakanans(MenuMakanans);
    }

}