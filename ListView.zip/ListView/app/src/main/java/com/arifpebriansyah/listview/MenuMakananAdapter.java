package com.arifpebriansyah.listview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class MenuMakananAdapter extends BaseAdapter{
    private Context context;
    private ArrayList<MenuMakanan> MenuMakanans;

    void setMenuMakanans(ArrayList<MenuMakanan> MenuMakanans) {
        this.MenuMakanans = MenuMakanans;
    }

    MenuMakananAdapter(Context context) {
        this.context = context;
        MenuMakanans = new ArrayList<>();
    }

    @Override
    public int getCount() {
        return MenuMakanans.size();
    }

    @Override
    public Object getItem(int i) {
        return MenuMakanans.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view==null){
            view= LayoutInflater.from(context).inflate(R.layout.item_makanan,viewGroup, false);
        }

        ViewHolder viewHolder = new ViewHolder(view);
        MenuMakanan MenuMakanan = (MenuMakanan) getItem(i);
        viewHolder.bind(MenuMakanan);
        return view;
    }

    private class ViewHolder{
        private TextView txtName;
        private TextView txtDescription;
        private ImageView imgPhoto;

        ViewHolder(View view){
            txtName=view.findViewById(R.id.txt_name);
            txtDescription=view.findViewById(R.id.txt_description);
            imgPhoto=view.findViewById(R.id.img_photo);
        }

        void bind(MenuMakanan MenuMakanan){
            txtName.setText(MenuMakanan.getName());
            txtDescription.setText(MenuMakanan.getDescription());
            imgPhoto.setImageResource(MenuMakanan.getPhoto());
        }
    }

}
